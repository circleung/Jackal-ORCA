#!/usr/bin/env python3

from typing import Optional

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import OccupancyGrid, Path
from tf2_ros import Buffer, TransformListener

from .utils import GridMap, astar, cells_to_path_msg


class AStarGlobalPlanner(Node):
    """
    입력:
      /map       nav_msgs/OccupancyGrid
      /goal_pose geometry_msgs/PoseStamped

    출력:
      /path      nav_msgs/Path

    역할:
      현재 로봇 위치(map -> base_link TF)에서 goal_pose까지 A* 경로 계산
    """

    def __init__(self):
        super().__init__("global_planner_astar")

        self.declare_parameter("map_topic", "/map")
        self.declare_parameter("goal_topic", "/goal_pose")
        self.declare_parameter("path_topic", "/path")
        self.declare_parameter("map_frame", "map")
        self.declare_parameter("robot_frame", "base_link")
        self.declare_parameter("planning_period", 0.5)
        self.declare_parameter("occupancy_occupied_threshold", 50)
        self.declare_parameter("allow_diagonal", True)
        self.declare_parameter("obstacle_inflation_radius", 0.25)
        self.declare_parameter("publish_empty_path_on_fail", True)

        self.map_topic = self.get_parameter("map_topic").value
        self.goal_topic = self.get_parameter("goal_topic").value
        self.path_topic = self.get_parameter("path_topic").value
        self.map_frame = self.get_parameter("map_frame").value
        self.robot_frame = self.get_parameter("robot_frame").value
        self.planning_period = float(self.get_parameter("planning_period").value)
        self.occupied_threshold = int(self.get_parameter("occupancy_occupied_threshold").value)
        self.allow_diagonal = bool(self.get_parameter("allow_diagonal").value)
        self.inflation_radius = float(self.get_parameter("obstacle_inflation_radius").value)
        self.publish_empty_path_on_fail = bool(self.get_parameter("publish_empty_path_on_fail").value)

        self.grid_map: Optional[GridMap] = None
        self.goal: Optional[PoseStamped] = None

        self.path_pub = self.create_publisher(Path, self.path_topic, 10)

        self.create_subscription(OccupancyGrid, self.map_topic, self.map_callback, 10)
        self.create_subscription(PoseStamped, self.goal_topic, self.goal_callback, 10)

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.timer = self.create_timer(self.planning_period, self.plan_timer_callback)

        self.get_logger().info("A* Global Planner started")

    def map_callback(self, msg: OccupancyGrid):
        self.grid_map = GridMap(msg, self.occupied_threshold)

    def goal_callback(self, msg: PoseStamped):
        self.goal = msg
        self.plan_and_publish()

    def plan_timer_callback(self):
        if self.goal is not None:
            self.plan_and_publish()

    def plan_and_publish(self):
        if self.grid_map is None or self.goal is None:
            return

        robot_pose = self.get_robot_pose()
        if robot_pose is None:
            return

        rx, ry = robot_pose
        gx = self.goal.pose.position.x
        gy = self.goal.pose.position.y

        start_cell = self.grid_map.world_to_grid(rx, ry)
        goal_cell = self.grid_map.world_to_grid(gx, gy)

        stamp = self.get_clock().now().to_msg()

        if start_cell is None or goal_cell is None:
            self.get_logger().warn("Start or goal is outside map.")
            self.publish_empty_path(stamp)
            return

        blocked = self.grid_map.inflate_obstacles(self.inflation_radius)

        cells = astar(
            self.grid_map,
            start_cell,
            goal_cell,
            blocked,
            allow_diagonal=self.allow_diagonal
        )

        if not cells:
            self.get_logger().warn("A* failed to find path.")
            self.publish_empty_path(stamp)
            return

        path_msg = cells_to_path_msg(self.grid_map, cells, self.map_frame, stamp)
        self.path_pub.publish(path_msg)

        self.get_logger().info(f"Path published: {len(path_msg.poses)} poses")

    def publish_empty_path(self, stamp):
        if not self.publish_empty_path_on_fail:
            return

        msg = Path()
        msg.header.frame_id = self.map_frame
        msg.header.stamp = stamp
        self.path_pub.publish(msg)

    def get_robot_pose(self):
        try:
            trans = self.tf_buffer.lookup_transform(
                self.map_frame,
                self.robot_frame,
                rclpy.time.Time()
            )
            return trans.transform.translation.x, trans.transform.translation.y
        except Exception as e:
            self.get_logger().warn(f"Cannot get robot pose: {e}")
            return None


def main(args=None):
    rclpy.init(args=args)
    node = AStarGlobalPlanner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
