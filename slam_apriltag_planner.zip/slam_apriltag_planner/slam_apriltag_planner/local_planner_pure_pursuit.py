#!/usr/bin/env python3

import math
from typing import Optional

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Path
from sensor_msgs.msg import LaserScan
from tf2_ros import Buffer, TransformListener

from .utils import clamp, normalize_angle, yaw_from_quaternion


class PurePursuitLocalPlanner(Node):
    """
    입력:
      /path nav_msgs/Path

    출력:
      /cmd_vel geometry_msgs/Twist

    역할:
      /path 위의 lookahead point를 따라가도록 Pure Pursuit 방식으로 속도 명령 생성
    """

    def __init__(self):
        super().__init__("local_planner_pure_pursuit")

        self.declare_parameter("path_topic", "/path")
        self.declare_parameter("cmd_vel_topic", "/cmd_vel")
        self.declare_parameter("scan_topic", "/scan")
        self.declare_parameter("map_frame", "map")
        self.declare_parameter("robot_frame", "base_link")
        self.declare_parameter("control_period", 0.05)
        self.declare_parameter("lookahead_distance", 0.8)
        self.declare_parameter("goal_tolerance", 0.25)
        self.declare_parameter("max_linear_speed", 0.35)
        self.declare_parameter("min_linear_speed", 0.05)
        self.declare_parameter("max_angular_speed", 0.8)
        self.declare_parameter("heading_slowdown_angle", 0.8)
        self.declare_parameter("obstacle_stop_distance", 0.45)
        self.declare_parameter("use_scan_safety_stop", True)

        self.path_topic = self.get_parameter("path_topic").value
        self.cmd_vel_topic = self.get_parameter("cmd_vel_topic").value
        self.scan_topic = self.get_parameter("scan_topic").value
        self.map_frame = self.get_parameter("map_frame").value
        self.robot_frame = self.get_parameter("robot_frame").value
        self.control_period = float(self.get_parameter("control_period").value)
        self.lookahead_distance = float(self.get_parameter("lookahead_distance").value)
        self.goal_tolerance = float(self.get_parameter("goal_tolerance").value)
        self.max_linear_speed = float(self.get_parameter("max_linear_speed").value)
        self.min_linear_speed = float(self.get_parameter("min_linear_speed").value)
        self.max_angular_speed = float(self.get_parameter("max_angular_speed").value)
        self.heading_slowdown_angle = float(self.get_parameter("heading_slowdown_angle").value)
        self.obstacle_stop_distance = float(self.get_parameter("obstacle_stop_distance").value)
        self.use_scan_safety_stop = bool(self.get_parameter("use_scan_safety_stop").value)

        self.path: Optional[Path] = None
        self.front_min_range = float("inf")

        self.cmd_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)

        self.create_subscription(Path, self.path_topic, self.path_callback, 10)

        if self.use_scan_safety_stop:
            self.create_subscription(LaserScan, self.scan_topic, self.scan_callback, 10)

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.timer = self.create_timer(self.control_period, self.control_loop)

        self.get_logger().info("Pure Pursuit Local Planner started")

    def path_callback(self, msg: Path):
        self.path = msg
        if len(msg.poses) == 0:
            self.stop_robot()

    def scan_callback(self, msg: LaserScan):
        ranges = list(msg.ranges)
        if not ranges:
            self.front_min_range = float("inf")
            return

        # 전방 ±30도 정도
        n = len(ranges)
        center = n // 2
        window = max(1, n // 12)

        front_ranges = ranges[center - window:center + window]
        valid = [r for r in front_ranges if not math.isnan(r) and not math.isinf(r)]

        self.front_min_range = min(valid) if valid else float("inf")

    def control_loop(self):
        if self.path is None or len(self.path.poses) == 0:
            self.stop_robot()
            return

        robot_pose = self.get_robot_pose()
        if robot_pose is None:
            self.stop_robot()
            return

        rx, ry, yaw = robot_pose

        if self.use_scan_safety_stop and self.front_min_range < self.obstacle_stop_distance:
            self.get_logger().warn("Obstacle detected. Stop.")
            self.stop_robot()
            return

        goal_pose = self.path.poses[-1].pose.position
        goal_dist = math.hypot(goal_pose.x - rx, goal_pose.y - ry)

        if goal_dist < self.goal_tolerance:
            self.stop_robot()
            return

        target = self.find_lookahead_point(rx, ry)
        if target is None:
            self.stop_robot()
            return

        tx, ty = target
        target_angle = math.atan2(ty - ry, tx - rx)
        alpha = normalize_angle(target_angle - yaw)

        cmd = Twist()

        # heading error가 크면 선속도를 낮추고 회전 위주로 진행
        heading_scale = max(0.0, 1.0 - abs(alpha) / self.heading_slowdown_angle)
        linear = self.max_linear_speed * heading_scale

        if abs(alpha) > 1.2:
            linear = 0.0
        else:
            linear = max(self.min_linear_speed, linear)

        # Pure Pursuit curvature: kappa = 2 sin(alpha) / Ld
        curvature = 2.0 * math.sin(alpha) / max(self.lookahead_distance, 0.001)
        angular = linear * curvature

        # 회전이 너무 작으면 목표 각도 오차 기반 보정
        if abs(linear) < 0.01:
            angular = 1.0 * alpha

        cmd.linear.x = clamp(linear, 0.0, self.max_linear_speed)
        cmd.angular.z = clamp(angular, -self.max_angular_speed, self.max_angular_speed)

        self.cmd_pub.publish(cmd)

    def find_lookahead_point(self, rx: float, ry: float):
        if self.path is None:
            return None

        poses = self.path.poses

        # 현재 위치에서 lookahead 거리 이상 떨어진 첫 번째 점 선택
        for pose_stamped in poses:
            px = pose_stamped.pose.position.x
            py = pose_stamped.pose.position.y
            dist = math.hypot(px - rx, py - ry)

            if dist >= self.lookahead_distance:
                return px, py

        # 남은 경로가 짧으면 마지막 점 선택
        last = poses[-1].pose.position
        return last.x, last.y

    def get_robot_pose(self):
        try:
            trans = self.tf_buffer.lookup_transform(
                self.map_frame,
                self.robot_frame,
                rclpy.time.Time()
            )

            x = trans.transform.translation.x
            y = trans.transform.translation.y
            yaw = yaw_from_quaternion(trans.transform.rotation)

            return x, y, yaw
        except Exception as e:
            self.get_logger().warn(f"Cannot get robot pose: {e}")
            return None

    def stop_robot(self):
        self.cmd_pub.publish(Twist())


def main(args=None):
    rclpy.init(args=args)
    node = PurePursuitLocalPlanner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.stop_robot()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
