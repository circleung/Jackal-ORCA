#!/usr/bin/env python3

import math
import random
from typing import List, Optional, Tuple

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import Bool
from tf2_ros import Buffer, TransformListener

from .utils import GridMap, make_pose_stamped


class GoalManager(Node):
    """
    평소: /map에서 Frontier 좌표를 찾아 /goal_pose 발행
    태그 발견 시: /tag_pose를 /goal_pose로 발행

    중요:
    /tag_detected(std_msgs/Bool)만으로는 태그의 실제 좌표를 알 수 없다.
    그래서 이 노드는 /tag_pose(geometry_msgs/PoseStamped)를 추가 입력으로 받도록 구성했다.
    YOLO/AprilTag 노드에서 태그의 map 기준 좌표를 계산해서 /tag_pose로 발행하면 된다.
    """

    def __init__(self):
        super().__init__("goal_manager")

        self.declare_parameter("map_topic", "/map")
        self.declare_parameter("goal_topic", "/goal_pose")
        self.declare_parameter("tag_detected_topic", "/tag_detected")
        self.declare_parameter("tag_pose_topic", "/tag_pose")
        self.declare_parameter("map_frame", "map")
        self.declare_parameter("robot_frame", "base_link")
        self.declare_parameter("use_tag_pose_topic", True)
        self.declare_parameter("frontier_publish_period", 1.0)
        self.declare_parameter("tag_goal_hold_time", 3.0)
        self.declare_parameter("min_frontier_distance", 0.8)
        self.declare_parameter("max_frontier_candidates", 500)
        self.declare_parameter("occupancy_occupied_threshold", 50)

        self.map_topic = self.get_parameter("map_topic").value
        self.goal_topic = self.get_parameter("goal_topic").value
        self.tag_detected_topic = self.get_parameter("tag_detected_topic").value
        self.tag_pose_topic = self.get_parameter("tag_pose_topic").value
        self.map_frame = self.get_parameter("map_frame").value
        self.robot_frame = self.get_parameter("robot_frame").value
        self.use_tag_pose_topic = self.get_parameter("use_tag_pose_topic").value
        self.period = float(self.get_parameter("frontier_publish_period").value)
        self.tag_goal_hold_time = float(self.get_parameter("tag_goal_hold_time").value)
        self.min_frontier_distance = float(self.get_parameter("min_frontier_distance").value)
        self.max_frontier_candidates = int(self.get_parameter("max_frontier_candidates").value)
        self.occupied_threshold = int(self.get_parameter("occupancy_occupied_threshold").value)

        self.grid_map: Optional[GridMap] = None
        self.tag_detected = False
        self.latest_tag_pose: Optional[PoseStamped] = None
        self.last_goal: Optional[Tuple[float, float]] = None
        self.last_tag_time = None

        self.goal_pub = self.create_publisher(PoseStamped, self.goal_topic, 10)

        self.create_subscription(OccupancyGrid, self.map_topic, self.map_callback, 10)
        self.create_subscription(Bool, self.tag_detected_topic, self.tag_detected_callback, 10)

        if self.use_tag_pose_topic:
            self.create_subscription(PoseStamped, self.tag_pose_topic, self.tag_pose_callback, 10)

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.timer = self.create_timer(self.period, self.timer_callback)

        self.get_logger().info("Goal Manager started")

    def map_callback(self, msg: OccupancyGrid):
        self.grid_map = GridMap(msg, self.occupied_threshold)

    def tag_detected_callback(self, msg: Bool):
        self.tag_detected = bool(msg.data)
        if self.tag_detected:
            self.last_tag_time = self.get_clock().now()

    def tag_pose_callback(self, msg: PoseStamped):
        self.latest_tag_pose = msg

    def timer_callback(self):
        if self.grid_map is None:
            return

        if self.should_use_tag_goal():
            self.publish_tag_goal()
            return

        self.publish_frontier_goal()

    def should_use_tag_goal(self) -> bool:
        if not self.tag_detected:
            return False

        if self.latest_tag_pose is None:
            self.get_logger().warn(
                "/tag_detected=True 이지만 /tag_pose가 없습니다. "
                "Bool만으로는 태그 좌표를 만들 수 없어서 Frontier 목표를 유지합니다."
            )
            return False

        return True

    def publish_tag_goal(self):
        tag_goal = PoseStamped()
        tag_goal.header.frame_id = self.map_frame
        tag_goal.header.stamp = self.get_clock().now().to_msg()
        tag_goal.pose = self.latest_tag_pose.pose

        self.goal_pub.publish(tag_goal)
        self.last_goal = (tag_goal.pose.position.x, tag_goal.pose.position.y)

        self.get_logger().info(
            f"Tag goal published: x={tag_goal.pose.position.x:.2f}, "
            f"y={tag_goal.pose.position.y:.2f}"
        )

    def publish_frontier_goal(self):
        robot_pose = self.get_robot_pose()
        if robot_pose is None:
            return

        rx, ry = robot_pose
        frontiers = self.find_frontiers()

        if not frontiers:
            self.get_logger().info("No frontier found.")
            return

        # 너무 가까운 frontier 제거
        candidates = [
            p for p in frontiers
            if math.hypot(p[0] - rx, p[1] - ry) >= self.min_frontier_distance
        ]

        if not candidates:
            return

        # 기본 정책: 가까운 frontier 선택
        goal_x, goal_y = min(
            candidates,
            key=lambda p: math.hypot(p[0] - rx, p[1] - ry)
        )

        # 같은 목표를 너무 자주 다시 발행하는 것 방지
        if self.last_goal is not None:
            if math.hypot(goal_x - self.last_goal[0], goal_y - self.last_goal[1]) < 0.3:
                return

        stamp = self.get_clock().now().to_msg()
        goal_msg = make_pose_stamped(self.map_frame, stamp, goal_x, goal_y, 0.0)
        self.goal_pub.publish(goal_msg)
        self.last_goal = (goal_x, goal_y)

        self.get_logger().info(f"Frontier goal published: x={goal_x:.2f}, y={goal_y:.2f}")

    def find_frontiers(self) -> List[Tuple[float, float]]:
        grid = self.grid_map
        if grid is None:
            return []

        frontiers = []

        for y in range(1, grid.height - 1):
            for x in range(1, grid.width - 1):
                cell = (x, y)

                if not grid.is_free(cell):
                    continue

                if self.is_next_to_unknown(cell):
                    frontiers.append(grid.grid_to_world(cell))

        if len(frontiers) > self.max_frontier_candidates:
            frontiers = random.sample(frontiers, self.max_frontier_candidates)

        return frontiers

    def is_next_to_unknown(self, cell: Tuple[int, int]) -> bool:
        grid = self.grid_map
        x, y = cell

        neighbors = [
            (x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1),
            (x + 1, y + 1), (x + 1, y - 1), (x - 1, y + 1), (x - 1, y - 1),
        ]

        return any(grid.is_unknown(n) for n in neighbors)

    def get_robot_pose(self):
        try:
            trans = self.tf_buffer.lookup_transform(
                self.map_frame,
                self.robot_frame,
                rclpy.time.Time()
            )
            return trans.transform.translation.x, trans.transform.translation.y
        except Exception as e:
            self.get_logger().warn(f"Cannot get robot pose: {e}")
            return None


def main(args=None):
    rclpy.init(args=args)
    node = GoalManager()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
