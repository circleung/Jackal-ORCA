import math
import heapq
from typing import List, Optional, Tuple

import numpy as np
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import OccupancyGrid, Path
from tf_transformations import euler_from_quaternion


GridCell = Tuple[int, int]
WorldPoint = Tuple[float, float]


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def normalize_angle(angle: float) -> float:
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


def yaw_from_quaternion(q) -> float:
    _, _, yaw = euler_from_quaternion([q.x, q.y, q.z, q.w])
    return yaw


def make_pose_stamped(frame_id: str, stamp, x: float, y: float, yaw: float = 0.0) -> PoseStamped:
    msg = PoseStamped()
    msg.header.frame_id = frame_id
    msg.header.stamp = stamp
    msg.pose.position.x = float(x)
    msg.pose.position.y = float(y)
    msg.pose.position.z = 0.0
    msg.pose.orientation.z = math.sin(yaw / 2.0)
    msg.pose.orientation.w = math.cos(yaw / 2.0)
    return msg


class GridMap:
    def __init__(self, msg: OccupancyGrid, occupied_threshold: int = 50):
        self.msg = msg
        self.width = msg.info.width
        self.height = msg.info.height
        self.resolution = msg.info.resolution
        self.origin_x = msg.info.origin.position.x
        self.origin_y = msg.info.origin.position.y
        self.occupied_threshold = occupied_threshold
        self.data = np.array(msg.data, dtype=np.int16).reshape((self.height, self.width))

    def in_bounds(self, cell: GridCell) -> bool:
        x, y = cell
        return 0 <= x < self.width and 0 <= y < self.height

    def is_unknown(self, cell: GridCell) -> bool:
        x, y = cell
        return self.in_bounds(cell) and self.data[y, x] == -1

    def is_free(self, cell: GridCell) -> bool:
        x, y = cell
        return self.in_bounds(cell) and self.data[y, x] == 0

    def is_occupied(self, cell: GridCell) -> bool:
        x, y = cell
        if not self.in_bounds(cell):
            return True
        value = self.data[y, x]
        return value >= self.occupied_threshold

    def world_to_grid(self, x: float, y: float) -> Optional[GridCell]:
        gx = int((x - self.origin_x) / self.resolution)
        gy = int((y - self.origin_y) / self.resolution)
        cell = (gx, gy)
        if not self.in_bounds(cell):
            return None
        return cell

    def grid_to_world(self, cell: GridCell) -> WorldPoint:
        gx, gy = cell
        wx = self.origin_x + (gx + 0.5) * self.resolution
        wy = self.origin_y + (gy + 0.5) * self.resolution
        return wx, wy

    def inflate_obstacles(self, radius_m: float) -> np.ndarray:
        blocked = self.data >= self.occupied_threshold
        blocked |= self.data == -1

        if radius_m <= 0.0:
            return blocked

        radius_cells = int(math.ceil(radius_m / self.resolution))
        inflated = blocked.copy()

        occupied_indices = np.argwhere(blocked)
        for y, x in occupied_indices:
            y0 = max(0, y - radius_cells)
            y1 = min(self.height, y + radius_cells + 1)
            x0 = max(0, x - radius_cells)
            x1 = min(self.width, x + radius_cells + 1)
            inflated[y0:y1, x0:x1] = True

        return inflated


def get_neighbors(cell: GridCell, allow_diagonal: bool = True):
    x, y = cell
    if allow_diagonal:
        moves = [
            (1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
            (1, 1, math.sqrt(2)), (1, -1, math.sqrt(2)),
            (-1, 1, math.sqrt(2)), (-1, -1, math.sqrt(2)),
        ]
    else:
        moves = [(1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0)]

    for dx, dy, cost in moves:
        yield (x + dx, y + dy), cost


def heuristic(a: GridCell, b: GridCell) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def astar(grid: GridMap, start: GridCell, goal: GridCell, blocked: np.ndarray, allow_diagonal: bool = True) -> List[GridCell]:
    if not grid.in_bounds(start) or not grid.in_bounds(goal):
        return []
    if blocked[start[1], start[0]] or blocked[goal[1], goal[0]]:
        return []

    open_heap = []
    heapq.heappush(open_heap, (0.0, start))

    came_from = {}
    g_score = {start: 0.0}
    visited = set()

    while open_heap:
        _, current = heapq.heappop(open_heap)

        if current in visited:
            continue
        visited.add(current)

        if current == goal:
            path = [current]
            while current in came_from:
                current = came_from[current]
                path.append(current)
            path.reverse()
            return path

        for nxt, step_cost in get_neighbors(current, allow_diagonal):
            if not grid.in_bounds(nxt):
                continue
            if blocked[nxt[1], nxt[0]]:
                continue

            tentative = g_score[current] + step_cost
            if tentative < g_score.get(nxt, float("inf")):
                came_from[nxt] = current
                g_score[nxt] = tentative
                f_score = tentative + heuristic(nxt, goal)
                heapq.heappush(open_heap, (f_score, nxt))

    return []


def cells_to_path_msg(grid: GridMap, cells: List[GridCell], frame_id: str, stamp) -> Path:
    path_msg = Path()
    path_msg.header.frame_id = frame_id
    path_msg.header.stamp = stamp

    for i, cell in enumerate(cells):
        x, y = grid.grid_to_world(cell)

        if i < len(cells) - 1:
            nx, ny = grid.grid_to_world(cells[i + 1])
            yaw = math.atan2(ny - y, nx - x)
        else:
            yaw = 0.0

        path_msg.poses.append(make_pose_stamped(frame_id, stamp, x, y, yaw))

    return path_msg
