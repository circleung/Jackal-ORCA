from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    pkg_share = get_package_share_directory('slam_apriltag_planner')
    params = os.path.join(pkg_share, 'config', 'planner_params.yaml')

    return LaunchDescription([
        Node(
            package='slam_apriltag_planner',
            executable='goal_manager',
            name='goal_manager',
            output='screen',
            parameters=[params],
        ),
        Node(
            package='slam_apriltag_planner',
            executable='global_planner_astar',
            name='global_planner_astar',
            output='screen',
            parameters=[params],
        ),
        Node(
            package='slam_apriltag_planner',
            executable='local_planner_pure_pursuit',
            name='local_planner_pure_pursuit',
            output='screen',
            parameters=[params],
        ),
    ])
