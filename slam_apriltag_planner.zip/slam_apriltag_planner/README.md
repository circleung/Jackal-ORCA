# slam_apriltag_planner

SLAM 기반 탐색 주행용 ROS2 Python 패키지입니다.

구조는 다음과 같습니다.

```text
Goal Manager
  평소: /map에서 Frontier 좌표를 찾아 /goal_pose 발행
  태그 발견 시: /tag_pose를 /goal_pose로 발행

Global Planner
  /map + /goal_pose 구독
  A*로 경로 계산
  /path 발행

Local Planner
  /path 구독
  Pure Pursuit로 /cmd_vel 발행
```

## Topic Interface

| Topic | Type | Direction |
|---|---|---|
| `/goal_pose` | `geometry_msgs/PoseStamped` | Goal Manager -> Global Planner |
| `/path` | `nav_msgs/Path` | Global Planner -> Local Planner |
| `/cmd_vel` | `geometry_msgs/Twist` | Local Planner -> Robot |
| `/tag_detected` | `std_msgs/Bool` | YOLO/Tag Node -> Goal Manager |
| `/tag_pose` | `geometry_msgs/PoseStamped` | YOLO/Tag Node -> Goal Manager |
| `/map` | `nav_msgs/OccupancyGrid` | SLAM -> Goal Manager, Global Planner |
| `/scan` | `sensor_msgs/LaserScan` | LiDAR -> Local Planner |

## 중요한 점

피드백에서 `/tag_detected(std_msgs/Bool)`만 제시되었지만, Bool 값만으로는 태그 좌표를 알 수 없습니다.

따라서 이 패키지는 태그 발견 여부는 `/tag_detected`, 태그의 목표 좌표는 `/tag_pose`로 받도록 구성했습니다.

YOLO/AprilTag 노드에서 태그의 좌표를 계산한 뒤 `/tag_pose`로 발행해야 Goal Manager가 태그 위치를 `/goal_pose`로 넘길 수 있습니다.

## Install

```bash
cd ~/ros2_ws/src
git clone <your-repo-url>
cd ~/ros2_ws
colcon build --packages-select slam_apriltag_planner
source install/setup.bash
```

## Run

```bash
ros2 launch slam_apriltag_planner slam_apriltag_planner.launch.py
```

## Parameters

`config/planner_params.yaml`에서 토픽명, frame명, 속도, lookahead 거리 등을 수정할 수 있습니다.

Jackal 네임스페이스가 붙어 있으면 예를 들어 다음처럼 바꾸세요.

```yaml
cmd_vel_topic: /j100_0000/cmd_vel
scan_topic: /j100_0000/scan
robot_frame: j100_0000/base_link
```

## Node 설명

### 1. Goal Manager

- `/map`을 보고 frontier를 계산합니다.
- 평소에는 가장 가까운 frontier를 `/goal_pose`로 발행합니다.
- `/tag_detected=True`이고 `/tag_pose`가 들어오면 태그 좌표를 `/goal_pose`로 발행합니다.

### 2. A* Global Planner

- `/map`과 `/goal_pose`를 구독합니다.
- 현재 로봇 위치는 TF `map -> base_link`에서 가져옵니다.
- OccupancyGrid에서 A* 경로를 계산합니다.
- 계산된 경로를 `/path`로 발행합니다.

### 3. Pure Pursuit Local Planner

- `/path`를 구독합니다.
- 현재 로봇 위치 기준 lookahead point를 선택합니다.
- Pure Pursuit 방식으로 `/cmd_vel`을 발행합니다.
- `/scan`을 이용해 전방 장애물이 가까우면 정지합니다.

## 기본 실행 전 확인

```bash
ros2 topic list
ros2 run tf2_tools view_frames
```

필수 토픽:

```text
/map
/goal_pose
/path
/cmd_vel
/tag_detected
/tag_pose
/scan
/tf
```

## License

MIT
