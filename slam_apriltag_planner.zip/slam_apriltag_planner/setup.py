from setuptools import setup
from glob import glob
import os

package_name = 'slam_apriltag_planner'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
    ],
    install_requires=['setuptools', 'numpy'],
    zip_safe=True,
    maintainer='daelohaseungmin',
    maintainer_email='daelohaseungmin@gmail.com',
    description='A* global planner, Pure Pursuit local planner, and frontier/tag goal manager for SLAM based AprilTag exploration.',
    license='MIT',
    entry_points={
        'console_scripts': [
            'goal_manager = slam_apriltag_planner.goal_manager:main',
            'global_planner_astar = slam_apriltag_planner.global_planner_astar:main',
            'local_planner_pure_pursuit = slam_apriltag_planner.local_planner_pure_pursuit:main',
        ],
    },
)
